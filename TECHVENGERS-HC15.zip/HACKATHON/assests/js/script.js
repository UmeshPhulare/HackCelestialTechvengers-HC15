document.addEventListener('DOMContentLoaded', function() {
    const questionList = document.getElementById('questionList');
    const rightSide = document.getElementById('rightSide');
    const askQuestionBtn = document.getElementById('askQuestionBtn');
    const questionModal = document.getElementById('questionModal');
    const modalClose = document.getElementById('modalClose');
    const submitQuestionBtn = document.getElementById('submitQuestionBtn');
    const questionInput = document.getElementById('questionInput');

    // Function to generate sample questions
    function generateQuestions() {
        for (let i = 1; i <= 10; i++) {
            const div = document.createElement('div');
            div.textContent = `Question ${i}`;
            div.addEventListener('click', function() {
                rightSide.textContent = this.textContent;
            });
            questionList.appendChild(div);
        }
    }
    
    generateQuestions();

    // Open the modal
    askQuestionBtn.addEventListener('click', function() {
        questionModal.style.display = 'block';
    });

    // Close the modal
    modalClose.addEventListener('click', function() {
        questionModal.style.display = 'none';
    });

    // Submit the new question
    submitQuestionBtn.addEventListener('click', function() {
        const newQuestion = questionInput.value.trim();
        if (newQuestion) {
            const div = document.createElement('div');
            div.textContent = newQuestion;
            div.addEventListener('click', function() {
                rightSide.textContent = this.textContent;
            });
            questionList.appendChild(div);
            questionInput.value = ''; // Clear the input field
            questionModal.style.display = 'none'; // Close the modal
        }
    });

    // Close the modal if the user clicks outside of it
    window.addEventListener('click', function(event) {
        if (event.target === questionModal) {
            questionModal.style.display = 'none';
        }
    });
});
