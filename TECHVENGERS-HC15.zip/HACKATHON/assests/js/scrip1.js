// code for YourQuestion.html

import { getDatabase, ref, get } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-database.js";
import { getFirestore, collection, addDoc, getDocs, onSnapshot } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";
import { query, orderBy } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js";
import { getStorage, ref as stRef, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-storage.js";

// Firestore configuration
const firebaseConfig = {
    apiKey: "AIzaSyAqeavToji8LRgcbs_Op1Q123ZTKjSD1ys",
    authDomain: "testing-9cea5.firebaseapp.com",
    projectId: "testing-9cea5",
    storageBucket: "testing-9cea5.appspot.com",
    messagingSenderId: "353233122883",
    appId: "1:353233122883:web:5c186fc3f9ba5375a746f6"
};

// Initializing Firebase for Firestore
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app); // Example initialization questions dikhan bnd
const userId = localStorage.getItem('userId');

// Realtime Database configuration
const realtimeConfig = {
    apiKey: "AIzaSyARz9p4VCxnoJ4vWD5Vg10s6-x89xYNZho",
    authDomain: "educonnect-8b19b.firebaseapp.com",
    projectId: "educonnect-8b19b",
    storageBucket: "educonnect-8b19b.appspot.com",
    messagingSenderId: "234561890601",
    appId: "1:234561890601:web:de78d5cab69c0cfae22f38",
    databaseURL: "https://educonnect-8b19b-default-rtdb.firebaseio.com"
};

// Initialize Realtime Database
const appRealtime = initializeApp(realtimeConfig, "realtimeApp");
const rtdb = getDatabase(appRealtime);


async function getUserData(userId) {
    console.log("Userid :"+userId);
    const userRef = ref(rtdb, 'users/' + userId);
    try {
        const snapshot = await get(userRef);
        if (snapshot.exists()) {
            const userData = snapshot.val();
            console.log("USERNAME : "+userData.name);
            return {
                name: userData.name,
                profilePictureURL: userData.profilePictureURL,
                usertype : userData.role
            };
        } else {
            console.log("No user data found");
            return { username: "Unknown", profilePictureURL: "assests/images/image.png" };
        }
    } catch (error) {
        // console.log("Error fetching user data: "+ error);
        return { username: "Unknown", profilePictureURL: "assests/images/image.png" };
    }
}

function loadQuestions() {
    const q = query(collection(db, "questions"), orderBy("createdAt", "desc"));
    getDocs(q).then((snapshot) => {
        const questionsList = document.getElementById("questionList");
        questionsList.innerHTML = ""; // Clear the list before rendering
        console.log(snapshot.size);
        snapshot.forEach(async (doc) => {
            const questionData = doc.data();
            const questionId = doc.id;
            const questionUserId = questionData.userID;

            // Fetch the user's details from the Realtime Database
            const userData = await getUserData(questionUserId);
            const questionItem = document.createElement("div");
            questionItem.classList.add("question-item");
            questionItem.innerHTML = `
            <div class="question-header">
                <img class="profile-pic" src="${userData.profilePictureURL}" alt="Profile Picture">
                <div class="user-info">
                    <div class="username">${userData.name}</div>
                    <div class="timestamp">${new Date(questionData.createdAt.seconds * 1000).toLocaleString()}</div>
                </div>
            </div>
            <div class="question-body">
                <p class="question">${questionData.question}</p>
            </div>
            `;
            questionItem.onclick = () => loadReplies(questionId);
            questionsList.appendChild(questionItem);
        });
    }).catch((e) => {
        console.log("Error loading questions:", e);
    });
}


function loadReplies(questionId) {
    const rightSide = document.getElementById('rightSide');
    rightSide.innerHTML = ""; // Clear the previous content

    // Show loading indicator while fetching the question
    rightSide.innerHTML = '<p>Loading question...</p>';

    // Fetch the question first
    getDoc(doc(db, "questions", questionId)).then((docSnap) => {
        if (docSnap.exists()) {
            const questionData = docSnap.data();
            const now = new Date();
            const futureTime = new Date(questionData.createdAt);
            futureTime.setTime(futureTime.getTime() + (24 * 60 * 60 * 1000)); // Add 24 hours
            const timeDifference = futureTime - now;

            // Conditional rendering based on the existence of fileurl
            let answersDocHTML = "";
            if (questionData.fileurl) {
                if (timeDifference < 0) {
                    answersDocHTML = `
                    <div id="answersdoc" style="display:block;">
                        <a id='downloadaDoc' href="${questionData.fileurl}">
                            <button>Download Answer After ${timeDifference}</button>
                        </a>
                    </div>`;
                } else {
                    answersDocHTML = `
                    <div id="answersdoc" style="display:block;">
                        <a href="${questionData.fileurl}">
                            <button>Download Answer Now</button>
                        </a>
                    </div>`;
                }
            }

            // Render question and answerdoc conditionally
            rightSide.innerHTML = `
                <div class="question-container">
                    <div class="question-details">
                        <span class="timestamp">${new Date(questionData.createdAt.seconds * 1000).toLocaleString()}</span>
                        <h2 class="question-text">${questionData.question}</h2>
                    </div>
                    ${answersDocHTML} <!-- Conditionally rendered answersDocHTML -->
                </div>
                <div id="replies"></div>
            `;

            // Fetch and display replies
            const q = query(collection(db, `questions/${questionId}/replies`), orderBy("repliedAt", "desc"));
            onSnapshot(q, (snapshot) => {
                const repliesDiv = document.getElementById('replies');
                if (snapshot.size === 0) {
                    repliesDiv.innerHTML = '<p class="user-name">No replies yet.</p>'; // In case there are no replies
                } else {
                    snapshot.forEach((doc) => {
                        const replyData = doc.data();
                        const replyItem = document.createElement("div");
                        replyItem.classList.add("reply");
                        replyItem.innerHTML = `
                            <div class="reply-content">
                                <img class="profile-pic" src="assests/images/image.png">
                                <div class="reply-text">
                                    <p><span class="user-name">Here Name Will Come | </span>
                                    <span style="color:#888; font-size:small;">${new Date(replyData.repliedAt.seconds * 1000).toLocaleString()}</span></p>
                                    <p class="reply-message">${replyData.reply}</p>
                                </div>
                            </div>
                        `;
                        repliesDiv.appendChild(replyItem); // Append replies after the question
                    });
                }
            });
        } else {
            rightSide.innerHTML = '<p>Question not found.</p>';
        }
    }).catch((e) => {
        console.log("Error loading question:", e);
        rightSide.innerHTML = '<p>Error loading question.</p>';
    });
}



function realTimeUpdates() {
    const query = collection(db, "questions");
    onSnapshot(query, (snapshot) => {
        loadQuestions(); // Refresh the question list on real-time update
    });
}

// Event listener for adding a new question
document.addEventListener("DOMContentLoaded", () => {
    // loadQuestions();
    realTimeUpdates();
});

async function addQuestion(questionText, userid, file) {
    try {
        let fileUrl = null;

        if (file != null) {
            // Create a storage reference
            const storageRef = stRef(storage, 'ansfile/' + file.name);
            // Upload the file
            await uploadBytes(storageRef, file);
            // Get the download URL
            fileUrl = await getDownloadURL(storageRef);
        }

        // Now add the question to Firestore
        const docRef = await addDoc(collection(db, "questions"), {
            question: questionText,
            createdAt: new Date(),
            userID: userid,
            ansfile: fileUrl // Store the URL instead of the file object
        });

        console.log("Question added with ID: ", docRef.id);
    } catch (error) {
        console.log("Error adding question: ", error);
    }
}

// ------------------------------------------ASK QUESTIION --------------------------------------------

// Open the modal
askQuestionBtn.addEventListener('click', function() {
    const questionModal = document.getElementById('questionModal');
    questionModal.style.display = 'block';
    const userId = localStorage.getItem('userId');
    const userData = getUserData(userId);
});

// Close the modal
modalClose.addEventListener('click', function() {
    const questionModal = document.getElementById('questionModal');
    questionModal.style.display = 'none';
});

// Close the modal if the user clicks outside of it
window.addEventListener('click', function(event) {
    const questionModal = document.getElementById('questionModal');
        if (event.target === questionModal) {
                questionModal.style.display = 'none';
            }
    });

// Submit the new question
submitQuestionBtn.addEventListener('click', async function() {
    // const questionList = document.getElementById('questionList');
    const questionModal = document.getElementById('questionModal');
    const questionInput = document.getElementById('questionInput');
    // const rightSide = document.getElementById('rightSide'); 
    const file = document.getElementById('file').files[0]; 
    const newQuestion = questionInput.value.trim();
    const userid = userId;
    if (newQuestion) {
        await addQuestion(newQuestion, userid, file);
        questionModal.style.display = 'none';
        questionInput.value = ''; // Clear the input field
    }
});