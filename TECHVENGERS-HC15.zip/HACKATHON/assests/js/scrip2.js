// code for test2.html

// code for YourQuestion.html

import { getDatabase, ref, get } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-database.js";
import { getFirestore, collection, addDoc, getDocs, onSnapshot } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";
import { query, orderBy } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js";
import { getStorage, ref as stRef, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-storage.js";

// Firestore configuration
const firebaseConfig = {
    apiKey: "AIzaSyAqeavToji8LRgcbs_Op1Q123ZTKjSD1ys",
    authDomain: "testing-9cea5.firebaseapp.com",
    projectId: "testing-9cea5",
    storageBucket: "testing-9cea5.appspot.com",
    messagingSenderId: "353233122883",
    appId: "1:353233122883:web:5c186fc3f9ba5375a746f6"
};

// Initializing Firebase for Firestore
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app); // Example initialization questions dikhan bnd
const userId = localStorage.getItem('userId');

// Realtime Database configuration
const realtimeConfig = {
    apiKey: "AIzaSyARz9p4VCxnoJ4vWD5Vg10s6-x89xYNZho",
    authDomain: "educonnect-8b19b.firebaseapp.com",
    projectId: "educonnect-8b19b",
    storageBucket: "educonnect-8b19b.appspot.com",
    messagingSenderId: "234561890601",
    appId: "1:234561890601:web:de78d5cab69c0cfae22f38",
    databaseURL: "https://educonnect-8b19b-default-rtdb.firebaseio.com"
};

// Initialize Realtime Database
const appRealtime = initializeApp(realtimeConfig, "realtimeApp");
const rtdb = getDatabase(appRealtime);

async function getUserData(userId) {
    console.log("Userid :"+userId);
    const userRef = ref(rtdb, 'users/' + userId);
    try {
        const snapshot = await get(userRef);
        if (snapshot.exists()) {
            const userData = snapshot.val();
            console.log("USERNAME : "+userData.name);
            return {
                name: userData.name,
                profilePictureURL: userData.profilePictureURL,
                usertype : userData.role
            };
        } else {
            console.log("No user data found");
            return { username: "Unknown", profilePictureURL: "assests/images/image.png" };
        }
    } catch (error) {
        // console.log("Error fetching user data: "+ error);
        return { username: "Unknown", profilePictureURL: "assests/images/image.png" };
    }
}

// Load all questions and display them in the left-side panel
function loadQuestions() {
    const q = query(collection(db, "questions"), orderBy("createdAt", "desc"));
    getDocs(q).then(snapshot => {
        const questionList = document.getElementById('questionList');
        questionList.innerHTML = '';  // Clear previous questions
        snapshot.forEach(async(doc) => {
            const questionData = doc.data();
            const questionItem = document.createElement('div');
            const questionUserId = questionData.userID;
            const userData = await getUserData(questionUserId);
            questionItem.classList.add('question-item');
            questionItem.innerHTML = `
                <div class="question-header">
                    <img class="profile-pic" src="${userData.profilePictureURL}" alt="Profile Picture">
                    <div class="user-info">
                        <div class="username">${userData.name}</div>
                        <div class="timestamp">${new Date(questionData.createdAt.seconds * 1000).toLocaleString()}</div>
                    </div>
                </div>
                <div class="question-body">
                    <p class="question">${questionData.question}</p>
                </div>
                
            `;
            questionItem.onclick = () => loadReplies(doc.id, questionData);
            questionList.appendChild(questionItem);
        });
    }).catch(error => {
        console.error("Error loading questions:", error);
    });
}

// Load replies for a specific question
// function loadReplies(questionId, questionData) {
//     const rightSide = document.getElementById('rightSide');
//     rightSide.innerHTML = `
//         <h1>${questionData.question}</h1>
//         <div id="replies"></div>
//         <div class="reply-input">
//             <textarea id="replyInput" placeholder="Type your reply..."></textarea>
//             <button id="replyBtn">Reply</button>
//         </div>
//     `;

//     // Add event listener to reply button
//     document.getElementById('replyBtn').addEventListener('click', () => {
//         const replyText = document.getElementById('replyInput').value;
//         if (replyText) {
//             addReply(questionId, replyText);
//         }
//     });

//     // Load replies from Firestore
//     const repliesDiv = document.getElementById('replies');
//     const repliesQuery = query(collection(db, `questions/${questionId}/replies`), orderBy("repliedAt", "desc"));
//     onSnapshot(repliesQuery, snapshot => {
//         repliesDiv.innerHTML = '';  // Clear previous replies
//         snapshot.forEach(doc => {
//             const replyData = doc.data();
//             const replyItem = document.createElement('div');
//             replyItem.innerHTML = `<div class="reply-content">
//                                 <img class="profile-pic" src="assests/images/image.png">
//                                 <div class="reply-text">
//                                 <span class="user-name">Here Name Will Come </span>
//                                 <p class="reply-message">${replyData.reply}</p>
//                                 </div>
//                             </div>`;
//             repliesDiv.prepend(replyItem);  // Prepend to show latest first
//         });
//     });
// }
async function loadReplies(questionId, questionData) {
    const rightSide = document.getElementById('rightSide');
    const userData = await getUserData(questionData.userID);
    rightSide.innerHTML = `
        <div class="question-container">
            <img class="profile-pic" src="${userData.profilePictureURL}">
            <div class="question-details">
                <span class="username">${userData.name}</span><br>
                <span class="timestamp">${new Date(questionData.createdAt.seconds * 1000).toLocaleString()}</span>
                <h2 class="question-text">${questionData.question}</h2>
            </div>
        </div>
        <div id="replies"></div>
        <div class="reply-input">
            <textarea id="replyInput" placeholder="Type your reply..."></textarea>
            <button id="replyBtn">Reply</button>
        </div>
    `;

    // Add event listener to reply button
    document.getElementById('replyBtn').addEventListener('click', () => {
        const replyText = document.getElementById('replyInput').value;
        const userID = localStorage.getItem('userId');
        if (replyText) {
            addReply(questionId, replyText, userID);
            loadReplies(questionId,questionData);
        }
    });

    // Load replies from Firestore
    const repliesDiv = document.getElementById('replies');
    const repliesQuery = query(collection(db, `questions/${questionId}/replies`), orderBy("repliedAt", "desc"));
    onSnapshot(repliesQuery, snapshot => {
        repliesDiv.innerHTML = '';  // Clear previous replies
        if (snapshot.size == 0) {
            replyItem.innerHTML = '<p class="user-name">No replies yet.</p>';
        } else {
            snapshot.forEach(async (doc) => {
                const replyData = doc.data();
                const userData = await getUserData(replyData.userID);
                const replyItem = document.createElement('div');
                replyItem.innerHTML = `<div class="reply-content">
                                    <img class="profile-pic" src="${userData.profilePictureURL}">
                                    <div class="reply-text">
                                    <p><span class="user-name">${userData.name}  | </span> <span style="color:#888; font-size:small;"> ${new Date(replyData.repliedAt.seconds * 1000).toLocaleString()}</span></p>
                                    <p class="reply-message">${replyData.reply}</p>
                                    </div>
                                </div>`;
                repliesDiv.prepend(replyItem);  // Prepend to show latest first
            });
        }
    });
}


// Add a new reply to Firestore
async function addReply(questionId, replyText, userId) {
    try {
        await addDoc(collection(db, `questions/${questionId}/replies`), {
            reply: replyText,
            repliedAt: new Date(),
            userID: userId
        });
        document.getElementById('replyInput').value = '';  // Clear input after sending
        console.log("REPLY ENTERD IN DB ");
    } catch (e) {
        console.error("Error adding reply:", e);
    }
}

// Initial load of questions
document.addEventListener("DOMContentLoaded", loadQuestions);
